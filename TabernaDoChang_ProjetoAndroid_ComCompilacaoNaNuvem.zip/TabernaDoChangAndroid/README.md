# Taberna do Chang — Projeto Android

Projeto Android nativo (Kotlin + WebView local) com interface HTML/CSS/JS empacotada dentro do APK.

## O que já está incluído
- Tela inicial com informações básicas da Taberna do Chang.
- Navegação: Início, Membros, Bar, Cantina, ChangCoins, Eventos, Halloween, Minha conta e Configurações.
- Cadastro local de membros.
- Cardápio do bar com valores em ChangCoins e carrinho.
- Cantina com preços sob consulta no balcão.
- Halloween Chang como evento dentro do app: interesse de participação para membros e botão de compra de ingresso.
- Campo administrativo para inserir link oficial de ingressos e WhatsApp da casa.
- Dados locais no aparelho via localStorage.
- Compartilhamento de pedido via menu de compartilhamento Android.
- Exportação de cópia JSON dos dados do app para a área privada Documentos do aplicativo.

## Gerar APK no Android Studio
1. Instale o Android Studio atualizado.
2. Extraia o ZIP do projeto.
3. No Android Studio, escolha **Open** e selecione a pasta `TabernaDoChangAndroid`.
4. Aguarde o Gradle Sync. Se solicitado, instale Android SDK Platform 35 e Build Tools.
5. Para gerar APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.
7. Para distribuir, use **Build > Generate Signed Bundle / APK** e crie uma chave de assinatura própria.

## Configurações que a administração precisa completar
- Abrir o app > Configurações.
- Inserir o link real de venda de ingressos (plataforma escolhida pela produção).
- Inserir o WhatsApp oficial da Taberna com código do país e DDD.

## Importante — limites desta primeira versão
- O cadastro e os pedidos ficam no aparelho em que foram feitos. Não existe ainda banco de dados compartilhado, painel administrativo remoto, autenticação centralizada ou sincronização entre celulares.
- O botão de ingresso só abre um checkout quando a produção cadastrar um link HTTPS válido. O app não cobra nem processa pagamentos por conta própria.
- O botão de pedido prepara/compartilha a mensagem para a equipe. Não envia pedidos automaticamente para uma cozinha ou PDV.
- Preços e itens estão configurados conforme as informações fornecidas para o projeto; confirme disponibilidade e valores no balcão.
- O evento Halloween aparece no menu como uma atividade da Taberna, não como a finalidade do aplicativo.

## Personalização
A interface principal fica em `app/src/main/assets/index.html`.
O código Android fica em `app/src/main/java/com/tabernadochang/app/MainActivity.kt`.


## Gerar o APK sem instalar Android Studio (compilação na nuvem)

O projeto inclui o workflow `.github/workflows/android-apk.yml`, que compila o APK nos servidores do GitHub.

1. Crie ou entre em uma conta gratuita em https://github.com.
2. Crie um repositório novo, por exemplo `taberna-do-chang-app`.
3. Envie todos os arquivos e pastas que estão dentro de `TabernaDoChangAndroid` para esse repositório (incluindo a pasta oculta `.github`).
4. Abra a aba **Actions** do repositório. Se o GitHub pedir, autorize os workflows.
5. Selecione **Gerar APK - Taberna do Chang** e toque em **Run workflow**. Também compila automaticamente quando houver envio para a branch `main`.
6. Quando terminar com status verde, abra a execução e baixe o artefato **Taberna-do-Chang-APK**.
7. Extraia o ZIP baixado para encontrar `app-debug.apk`; abra-o no Android e permita a instalação pelo navegador/gerenciador de arquivos, se solicitado.

Observações:
- O artefato de compilação fica disponível por 14 dias.
- Este é um APK de depuração para testes. Para distribuição pública, gerar uma versão assinada de lançamento e proteger a chave de assinatura.
- Não compartilhe credenciais ou chaves de assinatura no repositório.
