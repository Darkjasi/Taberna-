package com.tabernadochang.app

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class MainActivity : android.app.Activity() {
    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(18, 8, 20)
        window.navigationBarColor = android.graphics.Color.rgb(16, 8, 18)

        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.allowFileAccess = true
        webView.settings.allowContentAccess = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.webChromeClient = WebChromeClient()
        webView.addJavascriptInterface(AppBridge(this), "ChangApp")
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                if (uri.scheme == "https" || uri.scheme == "http") {
                    try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) {}
                    return true
                }
                return false
            }
        }
        webView.loadUrl("file:///android_asset/index.html")
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }

    class AppBridge(private val context: Context) {
        @JavascriptInterface fun openUrl(url: String) {
            (context as? MainActivity)?.runOnUiThread {
                try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
                catch (_: Exception) { Toast.makeText(context, "Não foi possível abrir o link.", Toast.LENGTH_SHORT).show() }
            }
        }

        @JavascriptInterface fun shareText(text: String) {
            (context as? MainActivity)?.runOnUiThread {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(Intent.EXTRA_TEXT, text)
                }
                context.startActivity(Intent.createChooser(intent, "Compartilhar pedido"))
            }
        }

        @JavascriptInterface fun exportText(filename: String, content: String, mime: String) {
            (context as? MainActivity)?.runOnUiThread {
                try {
                    val safeName = filename.replace(Regex("[^A-Za-z0-9._-]"), "_")
                    val dir = context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: context.filesDir
                    val file = File(dir, safeName)
                    FileOutputStream(file).use { it.write(content.toByteArray(Charsets.UTF_8)) }
                    Toast.makeText(context, "Arquivo salvo em Documentos do app: ${file.name}", Toast.LENGTH_LONG).show()
                    Toast.makeText(context, "Cópia salva na pasta Documentos do app.", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Falha ao exportar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}